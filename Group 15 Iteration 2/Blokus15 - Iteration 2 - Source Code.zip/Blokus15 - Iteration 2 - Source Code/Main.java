package Blokus15;


public class Main {
	public static void main(String[] args)
    {
        Blokus startgame = new Blokus();
        startgame.startGame();
    }
}
